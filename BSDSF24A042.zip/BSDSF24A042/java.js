document.getElementById('newsletter-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;

    if (name && email) {
        document.getElementById('form-message').textContent = `Thank you, ${name}! You've successfully subscribed.`;
        document.getElementById('newsletter-form').reset();
    } else {
        document.getElementById('form-message').textContent = 'Please fill out all fields!';
    }
});




document.getElementById('contact-form').addEventListener('submit', function (e) {
    e.preventDefault();

    const messageElement = document.getElementById('form-message');
    messageElement.textContent = "Thank you for reaching out! We will get back to you soon.";
    messageElement.style.display = "block";

    setTimeout(() => {
        messageElement.textContent = "";
    }, 5000);
});